from django.apps import AppConfig


class SampleAppConfig(AppConfig):
    name = 'app'
    verbose_name = 'Aplicativo'