from django_filters import FilterSet
from django_filters import filters

from .models import Item


class MyOrderingFilter(filters.OrderingFilter):
    descending_fmt = '%s （Ordem descrescente）'


class ItemFilter(FilterSet):

    name = filters.CharFilter(label='Nome completo', lookup_expr='contains')
    memo = filters.CharFilter(label='Observações', lookup_expr='contains')

    order_by = MyOrderingFilter(

        fields=(
            ('name', 'nome'),
            ('age', 'idade'),
        ),
        field_labels={
            'nome': 'nome',
            'age': 'idade',
        },
        label='Ordem de classificação'
    )

    class Meta:
        model = Item
        fields = ('name', 'sex', 'memo',)
